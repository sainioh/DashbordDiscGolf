CREATE VIEW course_stats AS
SELECT score.courseID,score.roundID, score.holeID, hole.holeNumber, score.strokes, score.putts, score.offTheTee
FROM score, hole, course
WHERE hole.holeID = score.holeID;

