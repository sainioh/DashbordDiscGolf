CREATE VIEW round_results AS
SELECT score.roundID, round.date as Date,(course.par - SUM(score.strokes)) as result
FROM score, round, course
WHERE round.roundID = score.roundID AND score.courseID = course.courseID
GROUP BY score.roundID
ORDER BY score.roundID;

