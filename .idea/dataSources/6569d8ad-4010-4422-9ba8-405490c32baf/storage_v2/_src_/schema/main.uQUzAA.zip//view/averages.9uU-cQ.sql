CREATE VIEW averages AS
SELECT score.courseID, score.holeID, hole.holeNumber, AVG(score.strokes), AVG(score.putts), hole.length
FROM score, hole, course
WHERE hole.holeID = score.holeID
GROUP BY score.holeID;

